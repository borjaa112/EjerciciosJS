const arrayNum = [3, 4, 6, 8, -2, -5];
let array = [];

for (let i = 0; i < arrayNum.length; i++) {
    array.push(arrayNum[i] * 2);
}

console.log(array);