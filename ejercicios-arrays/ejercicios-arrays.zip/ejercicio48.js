let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

if (arrayStr.indexOf("Pelota") !== -1) {
    console.log("El elemento se ha encontrado");
} else {
    console.log("El elemento no se ha encontrado");
}