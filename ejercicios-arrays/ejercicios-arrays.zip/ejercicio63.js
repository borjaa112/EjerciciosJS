let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

let palabrasMayorDeTres = arrayStr.filter(palabra => palabra.length > 3);
console.log(palabrasMayorDeTres);