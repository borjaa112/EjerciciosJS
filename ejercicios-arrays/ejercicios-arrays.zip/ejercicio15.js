let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];
let a = arrayStr.shift();
console.log(a);
console.log(arrayStr);

/*
el metodo shift borra el primer elemento del array y devuelve el elemento borrado.
*/