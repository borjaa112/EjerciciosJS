let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

let arrayStrOrdenado = arrayStr.sort();

console.log(arrayStrOrdenado);