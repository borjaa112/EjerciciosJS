let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];
arrayStr.pop();