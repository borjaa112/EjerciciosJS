const arrayNum = [3, 4, 6, 8, -2, -5];

if (arrayNum.includes(8)) {
    console.log("El elemento se ha encontrado");
} else {
    console.log("No se encuentra el elemento");
}