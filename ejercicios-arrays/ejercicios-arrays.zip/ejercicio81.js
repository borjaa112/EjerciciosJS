const arrayNum = [3, 4, 6, 8, -2, -5];

let arrayNumPlus = arrayNum.join("+");

arrayNum2 = arrayNumPlus.split("+");

console.log(arrayNumPlus);
console.log(arrayNum2);