/*
Ocurre que se imprimen los arrays elemento por elemento.
*/