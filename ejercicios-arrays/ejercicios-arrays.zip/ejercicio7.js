const arrayNum = [3, 4, 6, 8, -2, -5];
arrayNum.push(3);