const arrayNum = [3, 4, 6, 8, -2, -5];

let arrayNumDouble = arrayNum.map((num) => num * 2);

console.log(arrayNumDouble);