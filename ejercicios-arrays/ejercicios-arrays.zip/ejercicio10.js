const arrayNum = [3, 4, 6, 8, -2, -5];
arrayNum.unshift(2);
console.log(arrayNum);