/*
En la primera comparacion, aunque los datos sean los mismos el objeto es distinto
mientras que en la segunda comparacion se están comprobando dos objetos iguales, puesto
que no solo los datos son iguales, tambien el objeto.
*/