let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

let arrayStrComa = arrayStr.join();

arrayStr2 = arrayStrComa.split(',');

console.log(arrayStrComa);
console.log((arrayStr2));