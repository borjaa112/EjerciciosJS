let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];
arrayStr.shift();
console.log(arrayStr);