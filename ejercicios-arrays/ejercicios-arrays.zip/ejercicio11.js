let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];
arrayStr.unshift("Mesa");
console.log(arrayStr);