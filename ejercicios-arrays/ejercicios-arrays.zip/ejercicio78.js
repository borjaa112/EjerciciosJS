let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

let alfabeticoInverso = arrayStr.sort();
alfabeticoInverso = alfabeticoInverso.reverse();

console.log(alfabeticoInverso);