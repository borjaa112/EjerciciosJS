let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

if (arrayStr.includes("Patata")) {
    console.log("El elemento se ha encontrado");
} else {
    console.log("El elemento no se ha encontrado");
}