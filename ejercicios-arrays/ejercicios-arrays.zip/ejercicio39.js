const arrayNum = [3, 4, 6, 8, -2, -5];
let array = [];

for (let numero of arrayNum) {
    array.push(numero * 2);
}

console.log(array);