let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];
let array = [];
arrayStr.forEach((palabra) => array.push(palabra.toUpperCase()));

console.log(array);