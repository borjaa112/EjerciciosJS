/*
Usaré un for normal cuando necesite valor de la posicion.
En cualquier otro caso se usará for of por su "limpieza" en el codigo al no ser que necesite la posicion.
*/