const arrayNum = [3, 4, 6, 8, -2, -5];

let valor = arrayNum.find((numero) => numero < 0);
console.log(valor);