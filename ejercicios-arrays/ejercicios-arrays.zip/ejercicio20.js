let a = [0, 1, 2, 3, 4, 5];
let b = [];

while (a.length > 0) {
    b.push(a.slice(2));
}