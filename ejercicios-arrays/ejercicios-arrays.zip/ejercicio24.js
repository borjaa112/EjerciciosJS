let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

arrayStr.splice(-3);

for (let palabra of arrayStr) {
    console.log(palabra);
}