const arrayNum = [3, 4, 6, 8, -2, -5];
arrayNum.pop();
console.log(arrayNum);