const arrayNum = [3, 4, 6, 8, -2, -5];

if (arrayNum.indexOf(8) !== -1) {
    console.log("El elemento se ha encontrado");
} else {
    console.log("El elemento no se ha encontrado");
}