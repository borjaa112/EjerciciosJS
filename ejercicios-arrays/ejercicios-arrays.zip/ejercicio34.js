let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];
const arrayNum = [3, 4, 6, 8, -2, -5];

let todosElementos = arrayStr.concat(arrayNum);

console.log(todosElementos);