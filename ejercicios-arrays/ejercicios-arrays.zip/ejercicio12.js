let array = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado"];
let a = array.pop();
console.log(a);
console.log(array);

/*
El metodo pop elimina la ultima posicion del array y la devuelve.
*/