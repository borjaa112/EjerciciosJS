const arrayNum = [3, 4, 6, 8, -2, -5];

let arrayNumOrdenado = arrayNum.sort();

console.log(arrayNumOrdenado);