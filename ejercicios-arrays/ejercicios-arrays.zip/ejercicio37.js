/*
El metodo for each recorre cada elemento del array y ejecuta una funcion por cada elemento que se recorre
*/

const arrayNum = [3, 4, 6, 8, -2, -5];

//recorro cada elemento e imprimo cada posicion del array con un mensaje
arrayNum.forEach(numero => alert("El numero actual es: " + numero));