let array = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado"];
console.log(array);
let a = array.unshift("Domingo");
console.log(array);
console.log(a);

/*
El metodo unshift añade al principio del array el elemento pasado por argumento y devuelve
la nueva longitud del array.
*/