const arrayNum = [3, 4, 6, 8, -2, -5];

let newArrayNum = arrayNum.slice(0, 3);

console.log(newArrayNum);