let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

console.log(arrayStr.findIndex(palabra => palabra === "Pelota"));