const arrayNum = [3, 4, 6, 8, -2, -5];

let mayorMenor = arrayNum.sort();
mayorMenor = mayorMenor.reverse();

console.log(mayorMenor);