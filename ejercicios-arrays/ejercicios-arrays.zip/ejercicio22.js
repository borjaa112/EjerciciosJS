let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

arrayStr.splice(0, 1);

for (let palabra of arrayStr) {
    console.log(palabra);
}