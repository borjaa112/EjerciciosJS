let array = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado"];

let a = array.push("domingo");

console.log(a);
console.log(array);

/*
el método push añade al final de un array el elemento pasado y devuelve la nueva longitud
del array.
*/