let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

let ultimosElementos1 = arrayStr.slice(-2);

let ultimosElementos2 = arrayStr.slice(arrayStr.length - 2);

console.log(ultimosElementos1);
console.log(ultimosElementos2);