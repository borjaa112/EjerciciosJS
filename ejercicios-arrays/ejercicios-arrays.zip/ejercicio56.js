let arrayStr = ['casa', 'Pelota', '', 'NaranNja', 'aGuAcAtE'];

console.log(arrayStr.find(palabra => palabra.length > 3));