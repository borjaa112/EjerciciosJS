/* 
el metodo sort se ejecuta sobre un array existente y devuelve uno ordenado
*/

let numerosDesodenados = [5, 2, 1, 4, 6, 3]; //creo un array con numeros, pero sin ordenar

let numerosOrdenados = numerosDesodenados.sort(); //ejecuto el metodo sort

console.log(numerosOrdenados); //el array numerosOrdenados ahora muestra todos los elementos ordenados