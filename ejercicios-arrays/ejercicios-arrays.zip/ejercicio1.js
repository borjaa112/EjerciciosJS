/*
La diferencia entre const y let es que con let puedes redifinir la variable, pudiendo cambiar el valor
mientras que con const el valor es constante y no se puede modificar.

Lo único que const permite son modificaciones dentro de la estructura que contiene, como por ejemplo un array.
*/