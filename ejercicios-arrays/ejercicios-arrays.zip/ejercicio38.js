const arrayNum = [3, 4, 6, 8, -2, -5];
let array = [];

arrayNum.forEach(element => array.push(element * 2));

console.log(array);